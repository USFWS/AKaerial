## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, echo=FALSE--------------------------------------------------------
library(AKaerial)

## ----eval=FALSE---------------------------------------------------------------
#  my.data = DataSelect(data.path = "C:/data/data2020.csv",
#                       strata.path = "C:/strata/strata2020.shp",
#                       transect.path = "C:/transects/transects2020.shp",
#                       area = "YKD")
#  

## ----eval=FALSE---------------------------------------------------------------
#  my.estimates = Densities(my.dataselect, area = "YKD")

## ----echo=FALSE---------------------------------------------------------------
print(YKDHistoric$output.table[YKDHistoric$output.table$Year==2019,])

## ----eval=FALSE---------------------------------------------------------------
#  MasterFileList$DRIVE = "C:"
#  MasterFileList$DRIVE = "C:/MyMirror"
#  

## ----eval=FALSE---------------------------------------------------------------
#  my.table = EstimatesTable(area = "YKG", year = c(2005, 2021))
#  

## ----eval=FALSE---------------------------------------------------------------
#  my.table = EstimatesTable(area = "YKG", year = c(2005, 2021))
#  
#  write.csv(my.table$output.table, file="C:/Results/YKG_2005to2021_output.csv", quote=FALSE, row.names = FALSE)
#  
#  write.csv(my.table$expanded.table, file="C:/Results/YKG_2005to2021_expanded.csv", quote=FALSE, row.names = FALSE)
#  
#  write.csv(my.table$combined, file="C:/Results/YKG_2005to2021_combined.csv", quote=FALSE, row.names = FALSE)
#  

