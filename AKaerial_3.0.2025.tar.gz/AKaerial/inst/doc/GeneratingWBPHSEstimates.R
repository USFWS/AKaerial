## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, echo=FALSE--------------------------------------------------------
library(AKaerial)

## ----eval=FALSE---------------------------------------------------------------
# my.data = read.csv(file = "C:/data/data2020.csv")
# 
# my.adjusted.data = ReadWBPHS(my.data)
# my.flight = SummaryWBPHS(my.adjusted.data)
# 
# estimate = WBPHStidy(my.adjusted.data, my.flight)
# 

## ----eval=FALSE---------------------------------------------------------------
# MasterFileList_WBPHS$DRIVE = "C:"
# MasterFileList_WBPHS$DRIVE = "C:/MyMirror"
# 

## ----eval=FALSE---------------------------------------------------------------
# 
# estimates = WBPHSbyYear(2019)
# 

## ----eval=FALSE---------------------------------------------------------------
# my.table = WBPHSMultipleYear(years = c(1971, 2019))
# 

## ----eval=FALSE---------------------------------------------------------------
# my.table = WBPHSMultipleYear(years = c(1971, 2019))
# 
# write.csv(my.table, file="C:/Results/WBPHS_1971to2019.csv", quote=FALSE, row.names = FALSE)
# 

