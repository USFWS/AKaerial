#' Current table of accepted species codes and focal species for the USFWS Region 11 Migratory Bird Management portion of the North American (WBPHS) aerial survey
#'
#' Current table of accepted species codes and focal species for the USFWS Region 11 Migratory Bird Management portion of the North American (WBPHS) aerial survey.
#' For species on other MBM surveys, see \code{\link[AKaerial]{sppntable}}.
#' For more information on how estimates are generated, see \code{\link[AKaerial]{ReadWBPHS}} or \code{\link[AKaerial]{EstimatesWBPHS}}.
#' For more information on how species codes are used in analysis, see \code{\link[AKaerial]{GreenLight}}.
#'
#' @docType data
#'
#' @usage data(WBPHSsppntable)
#'
#' @format A data frame consisting of 137 rows of 6 variables:
#' \describe{
#'   \item{INPUT}{The character string representing all of the known ways a species code has been entered in raw data.}
#'   \item{COMMON}{The character string common name of the species represented.}
#'   \item{SCIENTIFIC}{The character string of the scientific name of the species represented.}
#'   \item{QAQC}{The corrected character string version of the species code for archived data files.}
#'   \item{WBPHS}{The character string conversion of the species code specific to the WBPHS survey.}
#'   \item{WBPHS_EST}{Binary [0,1] representing if a species is a focal species of the WBPHS survey (if an estimate should be produced).}
#'  }
#'
#'
"WBPHSsppntable"
