#' Current table of accepted species codes and focal species by project for USFWS Region 11 Migratory Bird Management aerial surveys
#'
#' Current table of accepted species codes and focal species by project for USFWS Region 11 Migratory Bird Management aerial surveys, including
#' ACP, BLSC, CRD, and YKD.  YKD includes both ducks and geese.  For WBPHS species, see \code{\link[AKaerial]{WBPHSsppntable}}.
#' For more information on how estimates are generated, see \code{\link[AKaerial]{DataSelect}} or \code{\link[AKaerial]{Densities}}.
#' For more information on how species codes are used in analysis, see \code{\link[AKaerial]{GreenLight}}.
#'
#' @docType data
#'
#' @usage data(sppntable)
#'
#' @format A data frame consisting of 568 rows of 12 variables:
#' \describe{
#'   \item{INPUT}{The character string representing all of the known ways a species code has been entered in raw data.}
#'   \item{COMMON}{The character string common name of the species represented.}
#'   \item{SCIENTIFIC}{The character string of the scientific name of the species represented.}
#'   \item{QAQC}{The corrected character string version of the species code for archived data files.}
#'   \item{ACP}{The character string conversion of the species code specific to the Arctic Coastal Plain survey.}
#'   \item{ACP_EST}{Binary [0,1] representing if a species is a focal species of the ACP survey (if an estimate should be produced).}
#'   \item{BLSC}{The character string conversion of the species code specific to the 2018 Black Scoter survey.}
#'   \item{BLSC_EST}{Binary [0,1] representing if a species is a focal species of the 2018 BLSC survey (if an estimate should be produced).}
#'   \item{CRD}{The character string conversion of the species code specific to the Copper River Delta survey.}
#'   \item{CRD_EST}{Binary [0,1] representing if a species is a focal species of the CRD survey (if an estimate should be produced).}
#'   \item{YKD}{The character string conversion of the species code specific to the Yukon-Kuskokwim River Delta surveys (ducks or geese).}
#'   \item{YKD_EST}{Binary [0,1] representing if a species is a focal species of the YKD surveys (if an estimate should be produced).}
#'  }
#'
#'
"sppntable"
